//
//  PicsCell.h
//  ZZPhotoKit
//
//  Created by Yuan on 16/1/13.
//  Copyright © 2016年 Ace. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PicsCell : UICollectionViewCell

@property(strong,nonatomic) UIImageView *photo;

@end
