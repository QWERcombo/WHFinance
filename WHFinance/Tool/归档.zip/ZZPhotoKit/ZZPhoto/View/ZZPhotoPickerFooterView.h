//
//  ZZPhotoPickerFooterView.h
//  ZZPhotoKit
//
//  Created by 袁亮 on 16/10/12.
//  Copyright © 2016年 Ace. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZPhotoPickerFooterView : UICollectionReusableView

@property (nonatomic, assign) NSInteger total_photo_num;

@end
